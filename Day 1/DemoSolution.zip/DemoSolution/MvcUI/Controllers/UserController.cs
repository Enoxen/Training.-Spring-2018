﻿using System.Web.Mvc;
using LogicGAC;

namespace MvcUI.Controllers
{
    public class UserController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]

        public ActionResult Index(string userName)
        {
            ViewBag.Message = GreetingClass.GreetingMethod(userName);
            return View("About");
        }
    }
}